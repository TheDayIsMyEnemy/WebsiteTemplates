module.exports = {
  open: true,
  server: {
    baseDir: "./",
    serveStaticOptions: {
      extensions: ["html"],
    },
  },
  files: "./",
  ignore: ["./node_modules/*"],
};
